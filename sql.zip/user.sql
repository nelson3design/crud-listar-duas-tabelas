-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 23-Fev-2022 às 13:35
-- Versão do servidor: 8.0.28
-- versão do PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `user`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tel` varchar(30) NOT NULL,
  `idade` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `nome`, `email`, `tel`, `idade`) VALUES
(11, 'nelson', 'pivane@gmail.com', '4899856534', '1991-02-24'),
(12, 'lorna-1', 'lorna@gmailcom', '4899856534', '2022-02-24'),
(14, 'pivane4', 'pivane4@gmail.com', '4899856534', '2022-02-24'),
(15, 'overt', 'overt@gmail.com', '4899856534', '1990-02-24'),
(16, 'nelson2', 'nelson2@gmail.com', '4899856534', '2022-02-24'),
(17, 'sony', 'sony@gmaill.com', '4899856534', '2022-02-25'),
(18, 'chico', 'chico@gmail.com', '4899856534', '2022-02-25');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_2`
--

DROP TABLE IF EXISTS `users_2`;
CREATE TABLE IF NOT EXISTS `users_2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rua` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `bairro` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `cidade` varchar(150) NOT NULL,
  `id_endereco` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `users_2`
--

INSERT INTO `users_2` (`id`, `rua`, `bairro`, `cidade`, `id_endereco`) VALUES
(8, 'rua carauna', 'bela vista', 'palhoça', 11),
(9, 'rua carauna', 'bela vista', 'palhoça', 12),
(11, 'braulio sebastião goulart', 'rio grande', 'palhoça', 14),
(12, 'braulio sebastião goulart', 'rio grande', 'palhoça', 15),
(13, 'rua carauna', 'bela vista', 'palhoça', 16),
(14, 'braulio sebastião goulart', 'rio grande', 'palhoça', 17),
(15, 'braulio sebastião goulart', 'rio grande', 'palhoça', 18);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
